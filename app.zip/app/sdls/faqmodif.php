<?php
require_once 'inc/bootstrap.php';
require_once 'inc/db.php';
if(!empty($_POST)){

// Formulaire

	$question = htmlspecialchars($_POST['FAQ_question']);
	$reponse = htmlspecialchars($_POST['FAQ_reponse']);
	$idfaq = htmlspecialchars($_POST['idFAQ']);
	$db->query("UPDATE faq SET idFAQ = ?,FAQ_question =?,FAQ_reponse=? WHERE idFAQ = ?",[$idfaq,$question,$reponse,$idfaq]);

}
header("Location: faqadmin.php");
exit();
?>