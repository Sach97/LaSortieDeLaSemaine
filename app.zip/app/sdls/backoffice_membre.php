<?php
/*-----------------------------------------------------------------------------------------------*/

                    //          ESPACE UTILISATEUR

/*----------------------------------------------------------------------------------------------*/
require_once 'inc/nav.php';
require 'inc/bootstrap.php';
App::getAuth()->restrict();
require_once 'inc/nav.header.php';



require_once 'inc/db.php';
$select_users = $db->query("SELECT * FROM utilisateur");
$users = $select_users->fetchAll(PDO::FETCH_ASSOC);
// var_dump($users);

?>



<div class="bocontainer">
  <h1>Membres</h1>
  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th scope="col" colspan="2">Utilisateur</th>
          <th scope="col">Email</th>
          <th scope="col">Récapitulatif</th>
          <th scope="col">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach($users as $row => $donnees) {?>
        <tr>
          <td data-th="Avatar">
            <span class="avatar">
              <img src="upload_files/profile_picture/<?=$donnees['photo_profil'];?>">
            </span>
          </td>
          <td data-th="Name">
            <h2><?= $donnees['pseudo']; ?></h2></td>
            <td data-th="Email">
              <a href="profile.php?id=<?=$donnees['id'];?>"><?= $donnees['email']; ?></a></td>
              <td data-th="Bio">
                <p>L'utilisateur est inactif depuis</p> <p>Ses évenements ont été signalés fois</p></td>
                <td data-th="Actions">
           <!--        <form action="bannir.php" methode="POST">

                    <button type="button" class="btn btn-primary">Bannir</button>
                  </form>
                </br>-->
                <form action="" methode="POST" onsubmit="return checkForm()">
                  <input type="text" value="<?=$donnees['id'];?>" hidden="hidden" name="supprime">
                  <input type="submit" class="btn btn-primary" name="supprimer" value="Supprimer">
                </form>

                <?php if(isset($_POST['supprimer'])){
                 require_once 'inc/db.php';
                 $supp=$_POST['supprime'];
                 $db->query("DELETE FROM utilisateur WHERE id = ?",[$supp]);
               } ?>
             </td>
           </tr>
           <?php } ?>
         </tbody>
       </table>
     </div>
   </div>


   <?php require_once 'inc/nav.footer.php'; ?>
   <?php require_once 'inc/footer.php'; ?>