<?php
require_once 'inc/bootstrap.php';
if(isset($_GET['motclef'])){
    $motclef = $_GET['motclef'];
    // $q = array();
    $sql = 'SELECT id, nom, description, date_debut, date_fin  FROM evenement WHERE nom like ? or description like ?';
    require_once 'inc/db.php';
    $req = $db->query($sql,['%'.$motclef.'%','%'.$motclef.'%']);
    $count = $req->rowCount($sql);

    if($count){
        while ($result = $req->fetch(PDO::FETCH_OBJ)){
            // var_dump($result);
            ?>
            <div class="event_result">
                <a href="fiche_event.php?id=<?=$result->id ;?>">
                    Nom : <?=$result->nom ;?><br/> Description: <?=$result->description; ?> <br/>
                    Date début: <?=$result->date_debut; ?> <br/>
                    Date fin: <?=$result->date_fin; ?> <br/>
                </a>
            </div>
            <?php  } ?>
            <?php }else {?>
            Aucun resultat pour : <?=$motclef; ?>
            <?php  } ?>
            <?php  } ?>



