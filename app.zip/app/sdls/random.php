<?php
$queue = array();
array_unshift($queue, "apple", "raspberry","Neo", "Morpheus", "Trinity", "Cypher", "Tank");
// Tableau
var_dump($queue);
$rand_keys = array_rand($queue, 2);
echo $queue[$rand_keys[0]] . "\n";
echo $queue[$rand_keys[1]] . "\n";



?>



<?php


require_once 'inc/bootstrap.php';
require_once 'inc/db.php';
// Affichage des donnnes
$select_evenement = $db->query("SELECT * FROM evenement2");
$evenement = $select_evenement->fetchAll(PDO::FETCH_ASSOC);
foreach($evenement as $row => $donnees) {
	// var_dump($row);

	?>


	<?php

// Tableau
	$queue =array(
		$row=>$donnees['e_photo']

		);
	// array_unshift($queue, $donnees['e_photo']);
	var_dump($queue);

// count($queue);


// $rnd_amount_needed = 2;
// if (count($queue) < $rnd_amount_needed) {$rnd_amount_needed = count($queue);}
// $rand_keys = array_rand($queue, $rnd_amount_needed);






// // $rand_keys = array_rand($queue, 2);
// echo $queue[$rand_keys[0]] . "\n";


}?>

