<?php
require_once 'inc/nav.php';
require_once 'inc/bootstrap.php';
require_once 'inc/db.php'; // on se connecte à notre base de données
// préparation de la requete
$select_forum = $db->query('SELECT id, auteur, titre, date_derniere_reponse FROM forum_sujets ORDER BY date_derniere_reponse DESC');
// $forum= $select_forum->fetchAll();
$nb_sujets = $select_forum -> rowCount();


?>

<form action="./insert_sujet.php" onsubmit="return checkForm()">

	<!-- on place un lien permettant d'accéder à la page contenant le formulaire d'insertion d'un nouveau sujet -->
	<input type="submit" name="Insérer un sujet" value="Insérer un sujet">

	<br /><br />

	<?php

	if ($nb_sujets == 0) {
		echo 'Aucun sujet';
	}
	else {
		?>
		<table width="500" border="1">
			<tr>
				<td class="title" id="author">
					Auteur
				</td>
				<td class="title" id="subject_title">
					Titre du sujet
				</td>
				<td class="title" id="last_answer_date">
					Date dernière réponse
				</td>
			</tr>
			<?php
	// on va scanner tous les tuples un par un
			while ($data=$nb_sujets->fetch(PDO::FETCH_OBJ)) {

			// foreach($forum as $row => $data) {

	// on décompose la date
				sscanf($data['date_derniere_reponse'], "%4s-%2s-%2s %2s:%2s:%2s", $annee, $mois, $jour, $heure, $minute, $seconde);
				die();

	// on affiche les résultats
				echo '<tr>';
				echo '<td class="authors">';

	// on affiche le nom de l'auteur de sujet
				echo htmlentities(trim($data['auteur']));
				echo '</td><td>';

	// on affiche le titre du sujet, et sur ce sujet, on insère le lien qui nous permettra de lire les différentes réponses de ce sujet
				echo '<a class="subjects" href="./lire_sujet.php?id_sujet_a_lire=' , $data['id'] , '">' , htmlentities(trim($data['titre'])) , '</a>';

				echo '</td><td class="last_answer_subject">';

	// on affiche la date de la dernière réponse de ce sujet
				echo $jour , '-' , $mois , '-' , $annee , ' ' , $heure , ':' , $minute;
			}
			?>
		</td></tr></table>
		<?php } ?>
	</form>
	<?php require_once 'inc/footer.php'; ?>


