<?php require_once 'inc/nav.php';
require_once 'inc/bootstrap.php';
require_once 'inc/db.php';
$select_evenement = $db->query("SELECT * FROM evenement");
$evenement = $select_evenement->fetchAll(PDO::FETCH_ASSOC);?>

<a href="" class="gros_titre">Photos</a>

<div class="wrapper">
	<div class="gallery">
		<ul>
			<?php foreach($evenement as $row => $donnees) {?>

			<li> <a href="fiche_event.php?id=<?=$donnees['id']; ?>"><img src="upload_files/event_photo/<?=$donnees['photo'];?>"></a></li>
			<?php }?>
		</ul>
	</div>
</div>



<?php require_once 'inc/footer.php'; ?>