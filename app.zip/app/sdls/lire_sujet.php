<DOCTYPE html>
	<html>

	<head>

		<title>Lecture d'un sujet</title>
		<meta charset="UTF-8">
		<link lang="fr">
		<link rel="stylesheet" href="beauty.css">
		<meta name="description" content="" />
		<meta name="keywords" content="" />

	</head>

	<body>


		<?php
		if (!isset($_GET['id_sujet_a_lire'])) {
			echo 'Sujet non défini.';
		}
		else {
			?>
			<table width="500" border="1"><tr>
				<td class="title">
					Auteur
				</td>
				<td class="title">
					Messages
				</td>
			</tr>
			<?php
require_once 'inc/db.php'; // on se connecte à notre base de données
// préparation de la requete

	// on prépare notre requête
$sql = 'SELECT auteur, message, date_reponse FROM forum_reponses WHERE correspondance_sujet="'.$_GET['id_sujet_a_lire'].'" ORDER BY date_reponse ASC';

	// on lance la requête (mysql_query) et on impose un message d'erreur si la requête ne se passe pas bien (or die)
$req = $db->query($sql);

	// on va scanner tous les tuples un par un
while ($data = $req->fetch()) {

	// on décompose la date
	sscanf($data['date_reponse'], "%4s-%2s-%2s %2s:%2s:%2s", $annee, $mois, $jour, $heure, $minute, $seconde);

	// on affiche les résultats
	echo '<tr>';
	echo '<td class=""read_author_and_date>';

	// on affiche le nom de l'auteur de sujet ainsi que la date de la réponse
	echo htmlentities(trim($data['auteur']));
	echo '<br />';
	echo $jour , '-' , $mois , '-' , $annee , ' ' , $heure , ':' , $minute;

	echo '</td><td class="read_message">';

	// on affiche le message
	echo nl2br(htmlentities(trim($data['message'])));
	echo '</td></tr>';
}
?>

<!-- on ferme notre table html -->
</table>
<br /><br />

<!-- on insère un lien qui nous permettra de rajouter des réponses à ce sujet -->
<form action="./insert_reponse.php?numero_du_sujet=<?php echo $_GET['id_sujet_a_lire']; ?>" onsubmit="return checkForm()">
	<input type="submit" name="Répondre" value="Répondre">
</form>

<?php
}
?>
<br /><br />

<!-- on insère un lien qui nous permettra de retourner à l'accueil du forum -->
<form action="./index.php" onsubmit="return checkForm()">
	<input type="submit" name="Retour à l'accueil" value="Retour à l'accueil">
</form>

</body>
</html>