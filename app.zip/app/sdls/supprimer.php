        <?php
        require_once 'inc/bootstrap.php';
        if(isset($_POST)){
        	$idsupp=$_POST['supp'];
        	require_once 'inc/db.php';
        	$db->query("DELETE FROM utilisateur WHERE id = ?",[$idsupp]);
        }
        ?>