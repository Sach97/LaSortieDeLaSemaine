<?php
require_once 'inc/nav.php';
require_once 'inc/bootstrap.php';
require_once 'inc/db.php';
$select_evenement = $db->query("SELECT * FROM evenement");
$evenement = $select_evenement->fetchAll(PDO::FETCH_ASSOC);

$select_evenement_distinct = $db->query("SELECT DISTINCT theme_interet FROM evenement");
$evenement_distinct = $select_evenement_distinct->fetchAll(PDO::FETCH_ASSOC);

?>


<!------------ GROS TITRE ------------>
<div class="main_event">
	<h1>La Sortie De La Semaine</h1>
</div>

<!-- BANNIERE -->
<a href="#">
	<div class="banniere">
	</div>
</a>
<script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.4.2/jquery.min.js"></script>
<script type="text/javascript" src="js/search.js"></script>
<script src="http://code.jquery.com/jquery-1.10.2.js"></script>

<script>
$(document).ready(function(){
	$('.category').on('change', function(){
		var category_list = [];
		$('#filters :input:checked').each(function(){
			var category = $(this).val();
			category_list.push(category);
		});

		if(category_list.length == 0)
			$('.resultblock').fadeIn();
		else {
			$('.resultblock').each(function(){
				var item = $(this).attr('data-tag');
				if(jQuery.inArray(item,category_list) > -1)
					$(this).fadeIn('slow');
				else
					$(this).hide();
			});
		}
	});
});
</script>



<div class="window-margin">
	<div class="window">
		<aside class="sidebar">
						<!--<div class="top-bar">
							<p class="logo"></p>
						</div> -->

					<!-- 	<div class="search-box">
							<input type="text" placeholder="rechercher...">
							<p class="fa fa-search"></p>
						</div> -->
						<div class="recherche">
							<input type="text" name="recherche" class="text" id="recherche"/>
							<p class="fa fa-search"></p>
							<div class="resultat" id="resultat"></div>
						</div>
					<!-- 	<div class="date-search">
							<input type="date" placeholder="Selectionner une date...">
						</div> -->



<!-- <menu class="menu">
				<div id="filters">
 		<div class="filterblock">
	 		  <input id="check1" type="checkbox" name="check" value="musique" class="category">
    		<label for="check1">Musique</label>
	 	</div>

 		<div class="filterblock">
	 		  <input id="check2" type="checkbox" name="check" value="gastronomie" class="category">
    		<label for="check2">Gastronomie</label>
	 	</div>

	 	<div class="filterblock">
	 		  <input id="check3" type="checkbox" name="check" value="sport" class="category">
    		<label for="check3">Sport</label>
	 	</div>
	 	<div class="filterblock">
	 		  <input id="check4" type="checkbox" name="check" value="cinema" class="category">
    		<label for="check3">Cinema</label>
	 	</div>
 	</div>
 </menu> -->














 <menu class="menu">

 	<div id="filters">


 		<?php foreach($evenement_distinct as $row => $donnees_distinct) {
 			// var_dump($evenement_distinct);

 			?>
 			<div class="filterblock">
 				<input id="check1" type="checkbox" name="check" value="<?= $donnees_distinct['theme_interet'];?>" class="category">
 				<label for="check1"><?= $donnees_distinct['theme_interet'];?></label>
 			</div>

 			<?php }?>

 		</div>

 		<!-- 	<div class="separator"></div> -->

							<!--<ul class="no-bullets">
<li><a href="#">news</a></li>
<li><a href="#">Commentaires</a></li>
<li><a href="#"></a></li>
<li><a href="#">Top </a></li>
</ul>
-->
<div class="separator"></div>
</menu>
</aside>


<div class="main" role="main">

	<div class="top-bar">

		<div class="profile-box">
			<div class="circle"></div>
			<span class="arrow fa fa-angle-down"></span>
		</div>

		<ul class="top-menu">
			<li class="menu-icon trigger-sidebar-toggle">
				<div class="line"></div>
				<div class="line"></div>
				<div class="line"></div>
			</li>
			<li><a href="#"></a></li>
			<li><a href="#"></a></li>
			<li class="active"><a href="#"></a></li>
			<li><a href="#"></a></li>
			<li><a href="#"></a></li>
			<li><a href="#"></a></li>
		</ul>

	</div> <!-- top bar -->



	<!-- featured -->


	<div class="movie-list">
		<div class="title-bar">
			<div class="left">
				<!-- <a class="payant" href="#"> Payant </a>

				<a class="gratuit" href="#"> Gratuit </a>

				<a class="T-date" href="#"> Trier par date </a>

				<a class="T-prix" href="#"> Trier par prix </a>

				<a class="T-nom" href="#"> Trier par nom </a>

				<a class="P-populaire" href="#"> Les plus populaires </a>

				<a class="A-pro" href="#"> A proximité </a> -->
			</div> <!-- left -->

		</div> <!-- title-bar -->



<!-- <div class="list">
					<li>
						<div class="resultblock" data-tag="musique">
						<img src="images/Affiche-paysage.jpg" alt="" class="cover">
						<p class="title">DAUM</p>
						<p class="genre">Musique, Culture</p>
						</div>
					</li>
					<li>

						<div class="resultblock" data-tag="musique">
						<img src="images/Opera.jpg" alt="" class="cover">
						<p class="title">Opéra / Ballet</p>
						<p class="genre">Culture, musique</p>
						</div>
					</li>
					<li>
						<div class="resultblock" data-tag="musique">
						<img src="images/After%20work%20mojito.jpg" alt="" class="cover">
						<p class="title">After Work</p>
						<p class="genre">Rencontre , Musique</p>
						</div>
					</li>
					<li>
						<div class="resultblock" data-tag="sport" style="display: block;">
						<img src="images/BADMINTON.jpg" alt="" class="cover">
						<p class="title">BADMINTON</p>
						<p class="genre">Sport </p>
						</div>
					</li>
					<li>


                                    </li><li>
						<div class="resultblock" data-tag="musique">
						<img src="images/Canne%20concert.jpg" alt="" class="cover">
						<p class="title">JAZZ CONCERT</p>
						<p class="genre">Musique </p>
						 </div>
					</li>
					<li>
						<div class="resultblock" data-tag="musique">
						<img src="images/Dancefloor.jpg" alt="" class="cover">
						<p class="title">100% Musique</p>
						<p class="genre">Musique, Rencontre</p>
						</div>
					</li>
					<li>
						<div class="resultblock" data-tag="gastronomie" style="display: block;">
						<img src="images/gastronomie.jpg" alt="" class="cover">
						<p class="title">Outre MER</p>
						<p class="genre">Gastronomie </p>
						</div>
					</li>
					<li>
						<div class="resultblock" data-tag="musique">
						<img src="images/hbqoadvxm2gt5ejis23w.jpg" alt="" class="cover">
						<p class="title">I LOVE TECHNO</p>
						<p class="genre">Musique, Rencontre</p>
						</div>
					</li>
					<li>
						<div class="resultblock" data-tag="cinema" style="display: block;">
						<img src="images/hunger%20game.jpg" alt="" class="cover">
						<p class="title">Hunger Games : Partie 2</p>
						<p class="genre">Cinema</p>
						</div>
					</li>
					<li>
						<div class="resultblock" data-tag="gastronomie" style="display: block;">
						<img src="images/pique%20nique.jpg" alt="" class="cover">
						<p class="title">Pique Nique</p>
						<p class="genre">gastronomie, Rencontre</p>
						</div>
					</li>
					<li>
						<div class="resultblock" data-tag="musique">
						<img src="images/reveillon.jpg" alt="" class="cover">
						<p class="title">Réveillon 2016</p>
						<p class="genre">Musique, Rencontre, Gastronomie</p>
						</div>
					</li>
					<li>
						<div class="resultblock" data-tag="gastronomie" style="display: block;">
						<img src="images/sallon%20fromage.jpg" alt="" class="cover">
						<p class="title">Fromages</p>
						<p class="genre">Gastronomie </p>
						</div>
					</li>
					<li>
						<div class="resultblock" data-tag="musique">
						<img src="images/trip%20teuf.jpg" alt="" class="cover">
						<p class="title">TRIP TEUF</p>
						<p class="genre">Musique, Rencontre</p>
						</div>
					</li>
					<li>
						<div class="resultblock" data-tag="sport" style="display: block;">
						<img src="images/AFFICHE-CASINO.jpg" alt="" class="cover">
						<p class="title">Casino</p>
						<p class="genre">Sport </p>
						</div>
					</li>
					<li>
						<div class="resultblock" data-tag="sport" style="display: block;">
						<img src="images/affiche-concours-petanque-2015.jpg" alt="" class="cover">
						<p class="title">Concours de pétanque</p>
						<p class="genre">Sport, Rencontre</p>
						</div>
					</li>
					<li>
						<div class="resultblock" data-tag="musique">
						<img src="images/affiche-soiree-mousse-ok.jpg" alt="" class="cover">
						<p class="title">Soirée MOUSSE</p>
						<p class="genre">Musique, Rencontre</p>
						</div>
					</li>
					<li>
						<div class="resultblock" data-tag="sport" style="display: block;">
						<img src="images/affiche_tournoi_foot.jpg" alt="" class="cover">
						<p class="title">Tournoi de FOOT</p>
						<p class="genre">Sport </p>
						</div>
					</li>
					<li>
						<div class="resultblock" data-tag="cinema" style="display: block;">
						<img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/22043/2014-03-08_140248_fmufrz_1.png" alt="" class="cover">
						<p class="title">Divergent</p>
						<p class="genre">Cinema</p>
					</div></li>

				</div> -->






				<div class="list">
					<?php foreach($evenement as $row => $donnees) {?>




					<li>
						<div class="resultblock" data-tag="<?= $donnees['theme_interet'];?>">
							<a href="fiche_event.php?id=<?= $donnees['id'];?>"><img src="upload_files/event_photo/<?= $donnees['photo'];?>" alt="" class="cover"></a>
							<p class="title"><?= $donnees['nom'];?></p>
							<p class="genre"><?= $donnees['theme_interet'];?></p>
						</div>
					</li>


					<?php }?>


				</div>

				<a href="#" class="load-more">Voir plus d'évenements <span class="fa fa-plus"></span></a>

			</div> <!-- évenements liste -->


		</div> <!-- main -->

	</div> <!-- window -->
</div>





<?php require_once 'inc/footer.php'; ?>