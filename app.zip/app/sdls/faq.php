<?php
require_once 'inc/bootstrap.php';
require_once 'inc/db.php';
if(!empty($_POST)){

// Formulaire
	$question = htmlspecialchars($_POST['FAQ_question']);
	$reponse = htmlspecialchars($_POST['FAQ_reponse']);
	$faq_insert=$db->prepare('INSERT INTO faq (FAQ_question,FAQ_reponse) VALUES (?,?)');
	$faq_edit=$faq_insert->execute([$question,$reponse]);

}

// Affichage des donnnes
$select_faq = $db->query("SELECT * FROM faq");
$faq = $select_faq->fetchAll(PDO::FETCH_ASSOC);
// var_dump($faq);
// die();
?>

<?php require_once 'inc/nav.php'; ?>
<!-- CODE HTML DU CONTENU -->

<?php foreach($faq as $row => $donnees) {
	// var_dump($donnees);

	?>


	<div class="faq_container">
		<ul class="accordion-menu">
			<li class="closed">
				<header onclick="toggle(this.parentNode)"><span class="title"><?=$donnees['FAQ_question']; ?></span></header>
				<section class="content">
					<p><?=$donnees['FAQ_reponse']; ?></p>
				</section>
			</li>


		</ul>
	</div>

	<?php }?>


	<!-- CODE JAVASCRIPT ACCORDEON -->
	<script>
	function toggle(e) {
		if(e.className == 'closed') {
			e.className = 'open';
		}
		else {
			e.className = 'closed';
		}
	}

	</script>

	<?php require_once 'inc/footer.php'; ?>