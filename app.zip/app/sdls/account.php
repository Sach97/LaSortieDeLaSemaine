<?php
/*-----------------------------------------------------------------------------------------------*/

                    //          ESPACE UTILISATEUR

/*----------------------------------------------------------------------------------------------*/
require 'inc/bootstrap.php';
App::getAuth()->restrict();
if(!empty($_POST)){

  if(empty($_POST['mdp']) || $_POST['mdp'] != $_POST['mdp_confirm']){
    $_SESSION['flash']['danger'] = "Les mots de passes ne correspondent pas";
  }else{
    $user_id = $_SESSION['auth']->id;
    $mdp= password_hash($_POST['mdp'], PASSWORD_BCRYPT);
    require_once 'inc/db.php';
    $db->query('UPDATE utilisateur SET mdp = ? WHERE id = ?',[$mdp, $user_id]);
    $_SESSION['flash']['success'] = "Votre mot de passe a bien été mis à jour";
  }

}
require_once 'inc/nav.php';
require_once 'inc/nav.header.php';
// var_dump($_SESSION['auth']);
?>




<h1><?= $_SESSION['auth']->pseudo; ?></h1>

<form action="" method="post">
  <div class="form-group">
    <input class="form-control" type="passwword" name="mdp" placeholder="Changer de mot de passe"/>
  </div>
  <div class="form-group">
    <input class="form-control" type="password" name="mdp_confirm" placeholder="Confirmation du mot de passe"/>
  </div>
  <button class="btn btn-primary">Modifier mot de passe</button>
</form>
</div>
</div>

<div class="well">
  <div class="container">



    <?php  if(!empty($_SESSION['auth']->photo_profil)): ?>

    <h1>Avatar</h1>
    <div class="profile_container">
      <form method="POST" action="upload.php" enctype="multipart/form-data">

        <div class="image-uploader" data-base-height="250" data-base-width="250">
          <div class="image">
            <img src="upload_files/profile_picture/<?=$_SESSION['auth']->photo_profil;?>" />
          </div> <!-- image  -->

          <input type="hidden" name="MAX_FILE_SIZE" value="100000"/>
          <input id="uploader" type="file" name="uploaded_profile"/>
          <input type="submit" name="envoyer" hidden="hidden"/>
          <button class="btn btn-primary">Modifier le fichier</button>



          <div class="zoom" style="display:none;">
            <div class="plus"></div>
            <div class="minus"></div>
            <div class="close"></div>
          </div> <!-- zoom -->

        </div>
        <br/>
      </form>






    </div> <!-- profile_container -->


  </div> <!--  container -->
</div>  <!-- well -->





<?php
/*----------------------------------------------------------------------------------------------*/
?>






<?php  else:?>

  <h1>Avatar</h1>
  <div class="profile_container">
    <form method="POST" action="upload.php" enctype="multipart/form-data">

      <div class="image-uploader" data-base-height="250" data-base-width="250">
        <div class="image">
          <img src="" />
        </div> <!-- image  -->

        <input type="hidden" name="MAX_FILE_SIZE" value="100000"/>
        <input id="uploader" type="file" name="uploaded_profile"/>
        <input type="submit" name="envoyer" hidden="hidden"/>
        <button class="btn btn-primary">Envoyer le fichier</button>



        <div class="zoom" style="display:none;">
          <div class="plus"></div>
          <div class="minus"></div>
          <div class="close"></div>
        </div> <!-- zoom -->

      </div>
      <br/>
    </form>






  </div> <!-- profile_container -->


</div> <!--  container -->
</div>  <!-- well -->


<?php endif; ?>






<<!-- div class="well">
  <div class="formcontainer">

   <h1>Informations personnelles</h1>

   <form class="">

   </form>
 </div> container
</div>   well  -->





<?php require_once 'inc/nav.footer.php'; ?>
<?php require_once 'inc/footer.php'; ?>