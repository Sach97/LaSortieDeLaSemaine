<?php
require_once 'inc/nav.php';
require_once 'inc/bootstrap.php';
require_once 'inc/db.php';
$select_evenement = $db->query("SELECT * FROM evenement");
$evenement = $select_evenement->fetchAll(PDO::FETCH_ASSOC);


$select_concert = $db->query("SELECT * FROM evenement WHERE theme_interet =? OR theme_interet =? OR theme_interet =?",["Musique", "Concert", "Festival"]);
$concerts = $select_concert->fetchAll(PDO::FETCH_ASSOC);

$select_theatres = $db->query("SELECT * FROM evenement WHERE theme_interet =? OR theme_interet =? OR theme_interet =?",["Art","Musée","Culture"]);
$theatres = $select_theatres->fetchAll(PDO::FETCH_ASSOC);

$select_cinema = $db->query("SELECT * FROM evenement WHERE theme_interet =?",["Cinéma"]);
$cinemas = $select_cinema->fetchAll(PDO::FETCH_ASSOC);

$select_clubbing = $db->query("SELECT * FROM evenement WHERE theme_interet =?",["Fête du Samedi Soir"]);
$clubbings = $select_clubbing->fetchAll(PDO::FETCH_ASSOC);
?>



<!-- GROS TITRE -->
<div class="main_event">
    <h1>La Sortie De La Semaine</h1>
</div>


<!-- BANNIERE -->
<a href="#">
    <div class="banniere">
    </div>
</a>


<!-- COLONNE GAUCHE -->
<div class="colonne_gauche">
    <a href="" class="gros_titre">Vos événements</a>
    <!--- Carousel -->
    <div class="carousel_wrapper">
        <div class="carousel-slideshow">

            <input id="button-1" type="radio" name="radio-set" class="carousel-selector-1" checked="checked" />
            <label for="button-1" class="button-label-1"></label>

            <input id="button-2" type="radio" name="radio-set" class="carousel-selector-2" />
            <label for="button-2" class="button-label-2"></label>

            <input id="button-3" type="radio" name="radio-set" class="carousel-selector-3" />
            <label for="button-3" class="button-label-3"></label>

            <input id="button-4" type="radio" name="radio-set" class="carousel-selector-4" />
            <label for="button-4" class="button-label-4"></label>

            <input id="button-5" type="radio" name="radio-set" class="carousel-selector-5" />
            <label for="button-5" class="button-label-5"></label>

            <label for="button-1" class="carousel-arrow carousel-a1"></label>
            <label for="button-2" class="carousel-arrow carousel-a2"></label>
            <label for="button-3" class="carousel-arrow carousel-a3"></label>
            <label for="button-4" class="carousel-arrow carousel-a4"></label>
            <label for="button-5" class="carousel-arrow carousel-a5"></label>

            <div class="carousel-content">
                <div class="carousel-parallax-bg"></div>
                <ul class="carousel-slider clearfix">
                    <li>
                        <a href="#"><img src="images/image01.jpg" alt="image01" />
                        </a>
                    </li>
                    <li>
                        <a href="#"><img src="images/image02.jpg" alt="image02" />
                        </a>
                    </li>
                    <li>
                        <a href="#"><img src="images/images03.png" alt="image03" />
                        </a>
                    </li>
                    <li>
                        <a href="#"><img src="images/images04.jpg" alt="image04" />
                        </a>
                    </li>
                    <li>
                        <a href="#"><img src="images/images05.jpg" alt="image05" />
                        </a>
                    </li>
                </ul><!-- carousel-slider clearfix -->
            </div><!-- carousel-content -->
        </div><!-- carousel-slideshow -->



                <!--------------------------- ANCIEN CAROUSEL--------------------------------------

<input type="checkbox" class="faux-ui-facia">
<div class="slide" slide="5" annot="Adrian Napster mix au Zig Zag">
<img src="https://ununsplash.imgix.net/uploads/141223808515744db9995/3361b5e1?q=75&fm=jpg&w=602" alt="Slide 5">
</div>

<input type="checkbox" class="faux-ui-facia">
<div class="slide" slide="4" annot="Speed Dating au deuxième étage de la Tour Eiffel">
<img src="https://unsplash.imgix.net/photo-1415356838286-df6fd593e8b3?q=75&fm=jpg&w=600" alt="Slide 4">
</div>

<input type="checkbox" class="faux-ui-facia">
<div class="slide" slide="3" annot="Dégustation de bonbons pour Halloween chez Gilberte">
<img src="https://ununsplash.imgix.net/reserve/JaI1BywIT5Or8Jfmci1E_zakopane.jpg?q=75&fm=jpg&w=600" alt="Slide 3">
</div>

<input type="checkbox" class="faux-ui-facia">
<div class="slide" slide="2" annot="Projection de films sur le toit de Romain">
<img src="https://ununsplash.imgix.net/uploads/1413387158190559d80f7/6108b580?fit=crop&fm=jpg&q=75&w=600" alt="Slide 2">
</div>

<input type="checkbox" class="faux-ui-facia">

<div class="slide" slide="1" annot="Tournoi de pétanque dans un lieu mythique" href="#">
<img src="https://ununsplash.imgix.net/uploads/1413399939678471ea070/2c0343f7?q=75&fm=jpg&w=601" alt="Slide 1">
</div>

<div class="counter" count="5"> / 5</div>
</div>
-->





</div>
<!-- carousel_wrapper -->
<!--GRILLE CATEGORIE -->
<ul class="grid">

    <?php foreach($concerts as $row => $concert) {?>
    <li>
        <div>
            <!--CONCERTS -->
            <a href="#" class="categorie">Concerts</a>
            <!-- Feature posts -->


            <div id="posts">

                <!-- 1 -->

                <div class="post" style="background-image: url('upload_files/event_photo/<?=$concert['photo'];?>');">
                    <div class='post-content'>
                        <h2><?=$concert['nom']; ?></h2>
                        <p><?=$concert['description']; ?></p>
                        <a href="fiche_event.php?id=<?=$concert['id']; ?>">Lire plus</a>
                    </div>
                </div>
            </div><!-- /posts -->
        </a>
        <?php }?>
    </div>
</li>

<?php foreach($theatres as $row => $theatre) {?>

<li>

    <div>
        <!-- THEATRES -->
        <a href="#" class="categorie">Théatres</a>
        <div id="posts">

            <!-- 1 -->
            <div class="post"style="background-image: url('upload_files/event_photo/<?=$theatre['photo'];?>');">
                <div class='post-content'>
                  <h2><?=$theatre['nom']; ?></h2>
                  <p><?=$theatre['description']; ?></p>
                  <a href="fiche_event.php?id=<?=$theatre['id']; ?>">Lire plus</a>
              </div>
          </div>

      </div><!-- /posts -->

      <?php }?>
  </div>
</li>


<?php foreach($cinemas as $row => $cinema) {?>
<li>
    <div>
        <!--BOUTONS -->
        <a href="#" class="categorie">Cinématographie</a>
        <div id="posts">

            <!-- 1 -->
            <div class="post"style="background-image: url('upload_files/event_photo/<?=$cinema['photo'];?>');">
                <div class='post-content'>
                  <h2><?=$cinema['nom']; ?></h2>
                  <p><?=$cinema['description']; ?></p>
                  <a href="fiche_event.php?id=<?=$cinema['id']; ?>">Lire plus</a>
              </div>
          </div>





      </div><!-- /posts -->

      <?php }?>
  </div>
</li>


<?php foreach($clubbings as $row => $clubbing) {?>
<li>
    <div>
        <!-- GASTRONOMIE -->
        <a href="#" class="categorie">Clubbing</a>
        <div id="posts">
           <!-- 1 -->
           <div class="post"style="background-image: url('upload_files/event_photo/<?=$clubbing['photo'];?>');">
            <div class='post-content'>
                <h2><?=$clubbing['nom']; ?></h2>
                <p><?=$clubbing['description']; ?></p>
                <a href="fiche_event.php?id=<?=$clubbing['id']; ?>">Lire plus</a>
            </div>
        </div>



    </div><!-- /posts -->
    <?php }?>
</div>
</li>

</ul><!-- grid -->



<!-- <a href="" class="gros_titre">Photos</a>
<div class="wrapper">
    <div class="gallery">
        <ul>


            <li><img src="http://webusers.imj-prg.fr/~jean-paul.allouche/buffet--.jpg"></li>
            <li><img src="http://semaine-etudiant.univ-toulouse.fr/sites/semaine-etudiant.univ-toulouse.fr/files/anciennes_editions/2013/sites/semaine-etudiant.univ-toulouse.fr/files/field/image/WEB%20Soir%C3%A9e%20internationale%202012%20-c-M.%20Vicente%20(1).jpg"></li>
            <li><img src="https://i.ytimg.com/vi/2UzQsyoOkzQ/maxresdefault.jpg"></li>
        </ul>
    </div>
</div>

<a href="" class="gros_titre">Vidéos</a>
<div class="wrapper">
    <div class="gallery">
        <ul>
            <li><img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/53819/9.png"></li>
            <li><img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/53819/2.png"></li>
            <li><img src="https://s3-us-west-2.amazonaws.com/s.cdpn.io/53819/3.png"></li>

        </ul>
    </div>
</div>  -->

</div><!-- colonne_gauche -->



<!-- COLONNE DROITE  -->
<div class="colonne_droite">
    <div class="actualites">
        <a href="" class="petit_titre">Actualités</a>
    </div>

    <!-- AGENDA -->
    <a href="" class="petit_titre">Agenda</a>
    <div class="widget_agenda">
        <ul>
            <li class="date">
                <h3>Nov 10</h3>
            </li>

            <li class="events">
                <ul class="events-detail">
                    <li>
                        <a href="#">
                            <span class="event-time">12h00 - </span>
                            <span class="event-name">Cérémonie des Oscars</span>
                            <br />
                            <span class="event-location">En savoir plus</span>
                        </a>
                    </li>

                    <li>
                        <a href="#">
                            <span class="event-time">14:00 - </span>
                            <span class="event-name">Cérémonie des Oscars</span>
                            <br />
                            <span class="event-location">En savoir plus</span>
                        </a>
                    </li>

                    <li>
                        <a href="#">
                            <span class="event-time">16:00 - </span>
                            <span class="event-name">Cérémonie des Oscars</span>
                            <br />
                            <span class="event-location">En savoir plus</span>
                        </a>
                    </li>

                    <li>
                        <a href="#">
                            <span class="event-time">18:00 - </span>
                            <span class="event-name">Cérémonie des Oscars</span>
                            <br />
                            <span class="event-location">En savoir plus</span>
                        </a>
                    </li>

                    <li>
                        <a href="#">
                            <span class="event-time">20:00 - </span>
                            <span class="event-name">Cérémonie des Oscars</span>
                            <br />
                            <span class="event-location">En savoir plus</span>
                        </a>
                    </li>
                </ul><!-- events-detail -->
            </li><!-- events -->
        </ul>
    </div><!-- widget_agenda -->




</div><!-- colonne_droite -->

<?php require_once 'inc/footer.php'; ?>