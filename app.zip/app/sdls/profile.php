<?php
require_once 'inc/bootstrap.php';
if (isset($_GET['id'])) {
    $userid=$_GET['id'];
    require_once 'inc/db.php';

    $select_users = $db->query("SELECT * FROM utilisateur WHERE id = ?",[$userid]);
    $users = $select_users->fetchAll(PDO::FETCH_ASSOC);
}


require_once 'inc/nav.php';
?>

<?php require_once 'inc/nav.header.php'; ?>

<?php foreach($users as $row => $donnees) {?>
<h1><?= $donnees['pseudo']; ?></h1>

<div class="well">
  <div class="container">

    <h3><?=$donnees['prenom'], $donnees['nom']; ?></h3>




    <?php  if(isset($donnees['photo_profil'])): ?>



    <div class="image">
        <img src="upload_files/profile_picture/<?=$donnees['photo_profil'];?>" />
    </div> <!-- image  -->




<?php endif;?>


</div> <!--  container -->
</div>  <!-- well -->

<?php } ?>










<?php require_once 'inc/nav.footer.php'; ?>
<?php require_once 'inc/footer.php'; ?>