<?php
require 'inc/bootstrap.php';
$auth = App::getAuth();
$db = App::getDatabase();
$auth->connectFromCookie($db);
if($auth->user()){
    App::redirect('account.php');
}
if(!empty($_POST) && !empty($_POST['pseudo']) && !empty($_POST['mdp'])) {
    $user = $auth->login($db, $_POST['pseudo'], $_POST['mdp'], isset($_POST['remember']));
    $session = Session::getInstance();
    if($user){
        $session->setFlash('success', 'Vous êtes maintenant connecté');
        App::redirect('account.php');
    }else{
        $session->setFlash('danger', 'Identifiant ou mot de passe incorrecte');
    }
}
?>
<?php require_once 'inc/nav.php'; ?>
<?php require_once 'inc/nav.header.php'; ?>

<h1>Se connecter</h1>

<form action="" method="POST">

    <div class="form-group">
        <label for="">Pseudo ou email</label>
        <input type="text" name="pseudo" class="form-control"/>
    </div>

    <div class="form-group">
        <label for="">Mot de passe <a href="forget.php">(J'ai oublié mon mot de passe)</a></label>
        <input type="password" name="mdp" class="form-control"/>
    </div>

    <div class="form-group">
        <label>
            <input type="checkbox" name="remember" value="1"/> Se souvenir de moi
        </label>
    </div>

    <button type="submit" class="btn btn-primary">Se connecter</button>

</form>
</div>
<?php require 'inc/nav.footer.php'; ?>