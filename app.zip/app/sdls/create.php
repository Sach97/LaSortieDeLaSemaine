<?php
require_once 'inc/bootstrap.php';
App::getAuth()->restrict();

if (empty($_POST)) { //On affiche un message d'erreur si les champs ne sont pas remplis
$_SESSION['flash']['danger'] = "Veuillez remplir tous les champs";
}else{


    $nombdd = htmlspecialchars($_POST['nom']);
    $date_debut = $_POST['date_debut'];
    $heure_debut = $_POST['heure_debut'];
    $date_fin = $_POST['date_fin'];
    $heure_fin = $_POST['heure_fin'];
    $adresse = htmlspecialchars($_POST['adresse']);
    //
    $code_postal = htmlspecialchars($_POST['code_postal']);
    $description= htmlspecialchars($_POST['description']);
    //
    $places= htmlspecialchars($_POST['nombre_place']);
    //
    //
    //
    //

    $user_id = $_SESSION['auth']->id; // Variable de session pour obtenir l'id de l'utilisateur
    $theme = htmlspecialchars($_POST['theme_interet']);
    require_once 'inc/db.php';
    $db->query('INSERT INTO evenement (nom,
        date_debut,
        heure_debut,
        date_fin,
        heure_fin,
        adresse,
        code_postal,
        description,
        nombre_place,createur,theme_interet) VALUES (?,?,?,?,?,?,?,?,?,?,?)',[$nombdd,
    $date_debut,
    $heure_debut,
    $date_fin,
    $heure_fin,
    $adresse,
    $code_postal,
    $description,
    $places, $user_id,$theme]);

                                // ID de l'événement créé
    $evenement_id = $db->lastInsertId();


                                // Déclaration des variables nécessaires à l'upload
$fileName = $_FILES["uploaded_event"]["name"]; // Nom d'origine du fichier
$fileTmpLoc = $_FILES["uploaded_event"]["tmp_name"]; // Fichier temporaire
$fileSize = $_FILES["uploaded_event"]["size"]; // Taille du fichier
$fileType = $_FILES["uploaded_event"]["type"]; // Taille du fichier
$fileErrorMsg = $_FILES["uploaded_event"]["error"];
$fileInfos = array(

    "size" => "L'image fait <strong>$fileSize</strong> bytes.",
    "type" => "Elle est du type <strong>$fileType</strong>"

    );
$extensions = array('jpg','gif','jpeg','png'); // Extensions autorisées
$extension = strtolower(substr(strrchr($fileName, '.'), 1)); // On extrait l'extension pour                                                                 // renommer le fichier
$taille_maxi = 1000000; // Taille autorisée
$nom = "{$evenement_id}.{$extension}"; // On définit le nom final du fichier
$target_path = "upload_files/event_photo/$nom";

//
if (!in_array($extension, $extensions)) {
    $_SESSION['flash']['danger'] = "Vous devez uploader un fichier de type png, jpg, jpeg ou  gif.";
    require_once 'inc/db.php';
    $db->query("DELETE FROM `sdls_soutenance`.`evenement` WHERE `evenement`.`id` = ?",[$evenement_id]);
}

if ($fileSize>$taille_maxi) {
    $_SESSION['flash']['danger'] = "La photo de votre événement est trop lourde. Veuillez télécharger un fichier de moins de 10Mo";
    require_once 'inc/db.php';
    $db->query("DELETE FROM `sdls_soutenance`.`evenement` WHERE `evenement`.`id` = ?",[$evenement_id]);}

    if (!isset($fileErrorMsg)) {
        move_uploaded_file($fileTmpLoc, $target_path);
        $db->query('UPDATE evenement SET photo = ? WHERE id = ?',[$nom, $evenement_id]);
        $_SESSION['flash']['success'] = "Votre événement a bien été créé";
    }
    move_uploaded_file($fileTmpLoc, $target_path);
    $db->query('UPDATE evenement SET photo = ? WHERE id = ?',[$nom, $evenement_id]);
    $_SESSION['flash']['success'] = "Votre événement a bien été créé";

}

?>

<?php
require_once 'inc/nav.php';
require_once 'inc/nav.header.php';
?>

<h1>Créer un événement</h1>

<?php if(!empty($errors)): ?>
    <div class="alert alert-danger">
        <p>Vous n'avez pas rempli le formulaire correctement</p>
        <ul>
            <?php foreach($errors as $error): ?>
            <li><?= $error; ?></li>
        <?php endforeach; ?>
    </ul>
</div>
<?php endif; ?>

<form action="" method="POST" id="form_id" enctype="multipart/form-data">

    <div class="form-group">
        <label for="">Nom de l'évenement</label>
        <input type="text" name="nom" class="form-control"/>
    </div>

    <div class="form-group">
        <label for="">Thème</label>
        <select name="theme_interet" class="form-control">

            <option value="Art" selected="selected">Art</option>
            <option value="Musée" selected="selected">Musée</option>
            <option value="Culture" selected="selected">Culture</option>
            <option value="Culinaire" selected="selected">Culinaire</option>
            <option value="Gastronomie" selected="selected">Gastronomie</option>
            <option value="Musique" selected="selected">Musique</option>
            <option value="Concert" selected="selected">Concert</option>
            <option value="Festival" selected="selected">Festival</option>
            <option value="Cinéma" selected="selected">Cinéma</option>
            <option value="Projection" selected="selected">Projection</option>
            <option value="Détente" selected="selected">Détente</option>
            <option value="Sport" selected="selected">Sport</option>
            <option value="Fête du Samedi Soir" selected="selected">Fête du Samedi Soir</option>
            <option value="Célibataire" selected="selected">Célibataire</option>
            <option value="Soirée Mousse" selected="selected">Soirée Mousse</option>
            <option value="Soirée Déguisée" selected="selected">Soirée Déguisée</option>
            <option value="Soirée Dansante" selected="selected">Soirée Dansante</option>
            <option value="Spectacle" selected="selected">Spectacle</option>
            <option value="Théâtre" selected="selected">Théâtre</option>
            <option value="Marché" selected="selected">Marché</option>
            <option value="Brocante" selected="selected">Brocante</option>
            <option value="Foire" selected="selected">Foire</option>
            <option value="Shopping" selected="selected">Shopping</option>
            <option value="Visite" selected="selected">Visite</option>
            <option value="Salon" selected="selected">Salon</option>
            <option value="Exposition" selected="selected">Exposition</option>

            <option value="Boire un verre" selected="selected">Boire un verre</option>

            <option value="Apéritif" selected="selected">Apéritif</option>
            <option value="Repas" selected="selected">Repas</option>
            <option value="Pique-Nique" selected="selected">Pique-Nique</option>
            <option value="Mode" selected="selected">Mode</option>
            <option value="Shopping" selected="selected">Shopping</option>
            <option value="Conférence" selected="selected">Conférence</option>
            <option value="Réunion de travail" selected="selected">Réunion de travail</option>
            <option value="" selected="selected">Choisir votre Thème</option>

        </select>


    </div>

    <div class="form-group">
        <label for="">Date de début</label>
        <input type="date" max="2017-01-25" min="2016-01-04" name="date_debut"  class="form-control"/>
    </div>

    <div class="form-group">
        <label for="">Date de fin</label>
        <input type="date" max="2017-01-25" min="2016-01-04" name="date_fin"  class="form-control"/>
    </div>

    <div class="form-group">
        <label for="">Heure de début</label>
        <input type="time" name="heure_debut"  class="form-control"/>
    </div>

    <div class="form-group">
        <label for="">Heure de fin</label>
        <input type="time" name="heure_fin"  class="form-control"/>
    </div>

    <div class="form-group">
        <label for="">Adresse</label>
        <input type="text" name="adresse" class="form-control" />
    </div>

    <div class="form-group">
        <label for="">Code Postal</label>
        <input type="number" minlength="5" maxlength="5" name="code_postal" class="form-control"/>
    </div>

    <div class="form-group">
        <label for="">Description</label>
        <textarea name="description" form="form_id" class="form-control"></textarea>

    </div>

    <div class="form-group">
        <label for="">Nombre de places</label>
        <input type="number" maxlength="3" name="nombre_place" class="form-control"/>
    </div>

    <?php /*------------------------------------------------------------------------------------*/?>
    <div class="form-group">

       <label for="">Photo</label>
   </div>
   <div class="profile_container">

    <div class="image-uploader" data-base-height="250" data-base-width="250">
      <div class="image">
        <img src="" />
    </div> <!-- image  -->

    <input type="hidden" name="MAX_FILE_SIZE" value="100000"/>
    <input id="uploader" type="file" name="uploaded_event"/>

    <div class="zoom" style="display:none;">
        <div class="plus"></div>
        <div class="minus"></div>
        <div class="close"></div>
    </div> <!-- zoom -->

</div>
<br/>

</div>

<button type="submit" class="btn btn-primary">Créer</button>

</form>

<?php


/*---------------------------------------------------------------------------------------*/?>

<?php require_once 'inc/nav.footer.php'; ?>
<?php require_once 'inc/footer.php'; ?>

