<?php
require_once 'inc/bootstrap.php';
if (isset($_GET['id'])) {
    $eventid=$_GET['id'];
    require_once 'inc/db.php';
    $select_evenement = $db->query("SELECT * FROM evenement WHERE id = ?",[$eventid]);
    $evenements = $select_evenement->fetchAll(PDO::FETCH_ASSOC);

}
if (isset ($_POST['signaler']))
{
    $compteur_signalement=$_POST['signalement'];
    require_once 'inc/db.php';
    $db->query('UPDATE evenement SET signaler = ? WHERE id=?',[$compteur_signalement,$eventid]);
}


require_once 'inc/nav.php';
require_once 'inc/nav.header.php'; ?>


<?php foreach($evenements as $row => $donnees) {
    $select_users = $db->query("SELECT * FROM utilisateur WHERE id = ?", [$donnees['createur']]);
    $users = $select_users->fetchAll(PDO::FETCH_ASSOC);?>
    <div class="block_titre_event">

        <?= $donnees['nom']; ?>


    </div>


    <div class="overall">


        <div class="block_photo_organisateur">



            <div class="block_photo">


                <img src="upload_files/event_photo/<?= $donnees['photo']; ?>" height="300" width="auto">


            </div>



            <div class="block_organisateur">

                Organisé par :
                <em class="name_organisateur">

                    <?php foreach($users as $row => $createur) { ?>

                    <a href="profile.php?id=<?=$donnees['createur']; ?>"> <?= $createur['pseudo'];?></a>




                    <?php } ?>









                </em>

            </div>



        </div>


        <div class="block_description">

            <div class="block_description_tete">

                Description

            </div>

            <div class="block_description_texte">

                <?= $donnees['description']; ?>

            </div>

        </div>



    </div>


    <div class="block_details">

        <div class="block_details_tete">

            Détails de l'évènement

        </div>

        <div class="block_details_texte">

            <div class="block_details_date_heure_lieu">

                <div class="details_date_lieu">

                    <div class="details_elements">

                        Date de début :   <?= $donnees['date_debut']; ?>

                    </div>

                    <div class="details_elements">

                        Heure de début :  <?= $donnees['heure_debut']; ?>

                    </div>

                    <div class="details_elements">

                        Date de fin : <?= $donnees['date_fin']; ?>

                    </div>

                    <div class="details_elements">

                        Heure de fin : <?= $donnees['heure_fin']; ?>

                    </div>

                </div>


                <div class="details_lieu">

                    <div class="details_elements">

                        <center><iframe
                            width="100%"
                            height="200px"
                            frameborder="0" style="border:0"
                            src="https://www.google.com/maps/embed/v1/place?key=AIzaSyCTQZ5rKhEnDfS2LJiU-hmV-DuCWpql02k
                            &q=<?=$donnees['adresse']; ?>&maptype=satellite">
                        </iframe><br /></center>

                    </div>

                </div>


            </div>





            <div class="details_themes">

                <div class="details_elements">

                 Thème(s) de l'évènement :
                 <em>
                     <li>
                        <?= $donnees['theme_interet']; ?>
                    </li>
              <!--      <li>
                       Thème 2
                   </li>
               -->               </em>

           </div>

       </div>

       <div class="details_places_type">

        <div class="details_elements">

            Nombre de places restantes : <?= $donnees['nombre_place']; ?>

        </div>

        <div class="details_elements" style="">

            Cet évènement est : <?php if($donnees['prive']==='0'): ?><em>Public</em>
        <?php else:?><em>Privé</em>
    <?php endif; ?>

</div>


</div><button class="btn btn-primary">Participer</button>
</div>

</div>
<div class="event_signal">

   <script language="javascript">

   var valeur=<?= $donnees['signaler']; ?>;
   function modifier(increment) {
    valeur+=increment;
    document.getElementById('text').value=valeur;
}

</script>
<form action="fiche_event.php?id=<?= $_GET['id'];?>" method="POST" onsubmit="return checkForm()">

    <div class="texte_incrementation">

        <input type="text" id="text" value="<?= $donnees['signaler']; ?>" name="signalement" size="3" readonly="true">


        <input type="submit" value="Signaler" name="signaler" onClick="modifier(+1)">

    </div>

    <script language="javascript">
    document.getElementById('text').value=valeur;
    </script>

</form>



</div>

<?php } ?>










<?php require_once 'inc/nav.footer.php'; ?>
<?php require_once 'inc/footer.php'; ?>