<?php
/*-----------------------------------------------------------------------------------------------*/

                    //          ESPACE UTILISATEUR

/*----------------------------------------------------------------------------------------------*/
require 'inc/bootstrap.php';
App::getAuth()->restrict();

require_once 'inc/db.php';

$select_evenement = $db->query("SELECT * FROM evenement WHERE signaler > 0");
$evenements = $select_evenement->fetchAll(PDO::FETCH_ASSOC);
// var_dump($evenements);
require_once 'inc/nav.php';
require_once 'inc/nav.header.php'; ?>



<div class="bocontainer">
  <h1>Evenements</h1>
  <div class="table-wrap">
    <table>
      <thead>
        <tr>
          <th scope="col" colspan="2">Evenement</th>
          <th scope="col">Créateur</th>
          <th scope="col">Récapitulatif</th>
          <th scope="col">Actions</th>
        </tr>
      </thead>
      <tbody>
        <?php foreach($evenements as $row => $donnees) {
          ?>

          <?php
          $select_users = $db->query("SELECT * FROM utilisateur WHERE id = ?", [$donnees['createur']]);
          $users = $select_users->fetchAll(PDO::FETCH_ASSOC);?>
          <tr>
            <td data-th="Avatar">
              <span class="avatar">
               <a href="fiche_event.php?id=<?=$donnees['id'];?>"><img src="upload_files/event_photo/<?=$donnees['photo'];?>"></a>
             </span>
           </td>
           <td data-th="Name">
            <h2><?= $donnees['nom']; ?></h2></td>

            <?php foreach($users as $row => $createur) { ?>
            <td data-th="Email">

              <a href="profile.php?id=<?=$donnees['createur'];?>"><?= $createur['pseudo']; ?></a</td>
                <?php } ?>
                <td data-th="Bio">
                  <!-- <p>L'événement a été créé il y a  </p> -->
                  <p>Il a été signalé <?=$donnees['signaler'];?> fois</p>
                </td>
                <td data-th="Actions">





                  <form action="" methode="POST" onsubmit="return checkForm()">
                    <input type="text" value="<?=$donnees['id'];?>" hidden="hidden" name="supprime">

                    <input type="submit" class="btn btn-primary" name="supprimer" value="Supprimer">
                  </form>

                  <?php if(isset($_POST['supprimer'])){
                   require_once 'inc/db.php';
                   $supp=$_POST['supprime'];
                   $db->query("DELETE FROM evenement WHERE id = ?",[$supp]);
                 } ?>









               </td>
             </tr>
             <?php } ?>
           </tbody>
         </table>
       </div>
     </div>


     <?php require_once 'inc/nav.footer.php'; ?>
     <?php require_once 'inc/footer.php'; ?>