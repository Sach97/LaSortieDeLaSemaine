<?php
require_once 'inc/bootstrap.php';

// Je veux récupérer le premier utilisateur


if(isset($_GET['id']) && isset($_GET['token'])){
    $auth = App::getAuth();
    $db = App::getDatabase();
    $utilisateur = $auth->checkResetToken($db, $_GET['id'], $_GET['token']);
    if($utilisateur){
        if(!empty($_POST)){
           /* $mdp = $auth->hashPassword($_POST['mdp']);
            $db->query('UPDATE utilisateur SET mdp = ? WHERE id = ?',[$mdp, $utilisateur->id]);*/

            $validator = new Validator($_POST);
            $validator->isConfirmed('mdp');
            if($validator->isValid()){
               $mdp = $auth->hashPassword($_POST['mdp']);
                $db->query('UPDATE utilisateur SET mdp = ?, reset_at = NULL, reset_token = NULL WHERE id = ?', [$mdp, $_GET['id']]);
                $auth->connect($utilisateur);
                Session::getInstance()->setFlash('success','Votre mot de passe a bien été modifié');
                App::redirect('account.php');
            }
        }
    }else{
        Session::getInstance()->setFlash('danger',"Ce token n'est pas valide");
        App::redirect('login.php');
    }
}else{
    App::redirect('login.php');
}

require 'inc/nav.php'; 
require 'inc/nav.header.php'; ?>
 <h1>Réinitialiser mon mot de passe</h1>

    <form action="" method="POST">

        <div class="form-group">
            <label for="">Mot de passe</label>
            <input type="password" name="mdp" class="form-control"/>
        </div>

        <div class="form-group">
            <label for="">Confirmation du mot de passe</label>
            <input type="password" name="mdp_confirm" class="form-control"/>
        </div>

        <button type="submit" class="btn btn-primary">Réinitialiser votre mot de passe</button>

    </form>

<?php require_once 'inc/nav.footer.php'; ?>
<?php require_once 'inc/footer.php'; ?>