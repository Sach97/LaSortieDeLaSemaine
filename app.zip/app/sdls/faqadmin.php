<?php
require_once 'inc/bootstrap.php';
require_once 'inc/db.php';




// Affichage des donnnes
$select_faq = $db->query("SELECT * FROM faq");
$faq = $select_faq->fetchAll(PDO::FETCH_ASSOC);
// var_dump($faq);
// die();

?>


<?php require_once 'inc/nav.php'; ?>

<!-- CODE HTML DU FORMULAIRE -->
<div class="well">
	<div class="formcontainer">
		<form action="faqajout.php" method="POST" id="form_id1">
			<div class="form-group">
				<label for="">Question</label>
				<textarea name="FAQ_question" form="form_id1" class="form-control"></textarea>
			</div>

			<div class="form-group">
				<label for="">Réponse</label>
				<textarea name="FAQ_reponse" form="form_id1" class="form-control"></textarea>
			</div>

			<button type="submit" class="btn btn-primary">Ajouter</button></br>

		</form>
	</div>
</div>


<?php foreach($faq as $row => $donnees) {
	// var_dump($donnees['idFAQ']);
	?>

	<div class="well">
		<div class="formcontainer">
			<form action="faqmodif.php" method="POST" id="form_id2">

				<textarea name="idFAQ" form="form_id2" class="form-control"><?=$donnees['idFAQ']; ?></textarea>
				<div class="form-group">

					<label for="">Question</label>
					<textarea name="FAQ_question" form="form_id2" class="form-control"><?=$donnees['FAQ_question']; ?></textarea>
				</div>

				<div class="form-group">
					<label for="">Réponse</label>
					<textarea name="FAQ_reponse" form="form_id2" class="form-control"><?=$donnees['FAQ_reponse']; ?></textarea>
				</div>

				<button type="submit" class="btn btn-primary">Modifier</button></br>

			</form>
		</div>
	</div>




	<?php }?>


</script>
<?php require_once 'inc/footer.php';?>