 <?php
 $class = 'bouton';
 $menuItems = array (
    "Accueil" => "index.php",
    "Que faire?" => "recherche.php",
    "Proposer" => "create.php",
    "Mon compte" => "register.php",
    "Forum" => "forum.php",
    "Galerie" => "galerie.php",
    );?>
    <!DOCTYPE html>
    <html lang="fr">
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <meta name="description" content="">
        <meta name="author" content="">
        <link rel="icon" href="../../favicon.ico">

        <title>La Sortie de La Semaine</title>

        <!-- c'est le css de la nav  -->

        <link href="css/main1.css" rel="stylesheet">

    </head>

    <body>
        <header>
            <picture>
                <!-- LOGO -->
                <source srcset="images/logo_plus_fonce_plus_petit.png" media="(max-width: 60em)">
                    <source srcset="images/logo_plus_fonce.png">
                        <img src="images/logo_plus_fonce.png" alt="Logo">
                    </picture>
                    <!-- BOUTONS -->

                    <?php
                    foreach($menuItems as $name => $url) {
                        echo "<a href='$url' class='$class'>$name</a>";
                    }
                    ?>

                </header>