<?php
$db = new Database();

