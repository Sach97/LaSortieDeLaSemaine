
<footer>
    <div class="splitter"></div>
    <ul>
        <li>
            <div class="icon" data-icon="E"></div>
            <div class="text">
                <h4>A propos</h4>
                <div>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin tristique justo eu sollicitudin pretium. Nam scelerisque arcu at dui porttitor, non viverra sapien pretium. Nunc nec dignissim nunc. Sed eget est purus. Sed convallis, metus in dictum feugiat, odio orci rhoncus metus. <a href="#">Lire plus</a></div>
            </div>
        </li>
        <li>
            <div class="icon" data-icon="a"></div>
            <div class="text">
                <h4>Archive</h4>
                <div>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin tristique justo eu sollicitudin pretium. Nam scelerisque arcu at dui porttitor, non viverra sapien pretium. Nunc nec dignissim nunc. Sed eget est purus. Sed convallis, metus in dictum feugiat, odio orci rhoncus metus. <a href="#">Lire plus</a></div>
            </div>
        </li>
        <li>
            <div class="icon" data-icon="s"></div>
            <div class="text">
                <h4>Partenaires</h4>
                <div>Lorem ipsum dolor sit amet, consectetur adipiscing elit. Proin tristique justo eu sollicitudin pretium. Nam scelerisque arcu at dui porttitor, non viverra sapien pretium. Nunc nec dignissim nunc. Sed eget est purus. Sed convallis, metus in dictum feugiat, odio orci rhoncus metus. <a href="#">Lire plus</a></div>
            </div>
        </li>
    </ul>

    <div class="bar">
        <div class="bar-wrap">
            <ul class="links">
                <li><a href="index.php">Accueil</a></li>
                <li><a href="faq.php">FAQ</a></li>
                <li><a href="#">Nous contacter</a></li>
                <li><a href="#">Mentions légales</a></li>
                <li><a href="#">A propos</a></li>
            </ul>

            <div class="social">
                <a href="#" class="fb">
                    <span data-icon="f" class="icon"></span>
                    <span class="info">
                        <span class="follow">Devenez un de nos fans Facebook</span>
                        <span class="num">9,999</span>
                    </span>
                </a>

                <a href="#" class="tw">
                    <span data-icon="T" class="icon"></span>
                    <span class="info">
                        <span class="follow">Suivez nous sur Twitter</span>
                        <span class="num">9,999</span>
                    </span>
                </a>

                <a href="#" class="rss">
                    <span data-icon="R" class="icon"></span>
                    <span class="info">
                        <span class="follow">S'abonner au flux RSS</span>
                        <span class="num">9,999</span>
                    </span>
                </a>
            </div>
            <div class="clear"></div>
            <div class="copyright">&copy; <?php echo date('Y'); ?> Tous droits réservés</div>
        </div>
    </div>
</footer>


</body>

</html>