
<?php
/*-----------------------------------------------------------------------------------------------*/

                    //          ESPACE ADMIN

/*----------------------------------------------------------------------------------------------*/
require_once 'inc/nav.php';
require 'inc/bootstrap.php';
App::getAuth()->restrict();
require_once 'inc/nav.header.php';


?>


<ul>
	<li>
		<a href="backoffice_evenement.php">Gestion des évenements</a>
	</li>
	<li>
		<a href="backoffice_membre.php">Gestion des membres</a>
	</li>
	<li>
		<a href="faqadmin.php">Gestion de la faq</a>
	</li>
</ul>

<?php require_once 'inc/nav.footer.php'; ?>
<?php require_once 'inc/footer.php'; ?>