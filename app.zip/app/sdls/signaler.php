<?php
require_once 'inc/bootstrap.php';
if (isset ($_POST['inscription']))
{

	$compteur_places=$_POST['places_restantes'];
	require_once 'inc/db.php';

	$db->query('UPDATE evenement SET nombre_place= ? WHERE id= ?', [$compteur_places,$_GET['id']]);

}



// $select_signaler=$db->query('SELECT signaler FROM evenement WHERE id =?',[$_GET['id']]);
// $count_init=$select_signaler->fetch();
// $db->query('UPDATE evenement SET signaler = ? WHERE id = ?',[$count_init+1, $_GET['id']]);


header('Location: event.php?id='.$_GET['id'].);
exit();
?>