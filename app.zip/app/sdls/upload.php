<?php
/*----------------------------------------------------------------------------------------------*/
								// 			INCLUSIONS
/*----------------------------------------------------------------------------------------------*/

require 'inc/bootstrap.php';
require 'inc/nav.php';
require 'inc/nav.header.php';
App::getAuth()->restrict();



/*----------------------------------------------------------------------------------------------*/
								// 			DEFINITION DES VARIABLES
/*----------------------------------------------------------------------------------------------*/

$user_id = $_SESSION['auth']->id; // Clé primaire spécifique à l'utilisateur dans la bdd
$fileName = $_FILES["uploaded_profile"]["name"]; // Nom d'origine du fichier
$fileTmpLoc = $_FILES["uploaded_profile"]["tmp_name"]; // Fichier temporaire
$fileSize = $_FILES["uploaded_profile"]["size"]; // Taille du fichier
$fileType = $_FILES["uploaded_profile"]["type"]; // Taille du fichier
$fileErrorMsg = $_FILES["uploaded_profile"]["error"];
$fileInfos = array(

	"size" => "L'image fait <strong>$fileSize</strong> bytes.",
	"type" => "Elle est du type <strong>$fileType</strong>"

	);
$extensions = array('jpg','gif','jpeg','png'); // Extensions autorisées
$extension = strtolower(substr(strrchr($fileName, '.'), 1)); // On extrait l'extension pour 																// renommer le fichier
$taille_maxi = 100000; // Taille autorisée
$nom = "{$user_id}.{$extension}"; // On définit le nom final du fichier
$target_path = "upload_files/profile_picture/$nom";


/*----------------------------------------------------------------------------------------------*/
								// 			UPLOAD
/*----------------------------------------------------------------------------------------------*/
?>



<?php if(!in_array($extension, $extensions)): //Vérification de l'extension ?>
	<div class="alert alert-danger">
		<p>Vous devez uploader un fichier de type png, jpg, jpeg ou  gif.</p>
	</div>
<?php endif; ?>

<?php if($fileSize>$taille_maxi): //Vérification de la taille ?>
	<div class="alert alert-success">
		<p>Le fichier est trop gros</p>
	</div>
<?php endif; ?>

<?php if(!isset($fileErrorMsg)) ?>
<?php $moveResult = move_uploaded_file($fileTmpLoc, $target_path); // Fonction php qui déplcace le 																	//fichier temporaire vers le 																	//dossier de destination défini 																//préalablement
?>
<?php if($moveResult != true): ?>
	<div class="alert alert-danger">
		<p>ERREUR: Fichier non uploadé. Veuillez réessayer.</p>
		<?php unlink($fileTmpLoc); ?>
	</div>
<?php else: ?>
	<div class="alert alert-success">
		<p>Le fichier a été uploadé correctement</p>
		<ul>
			<?php foreach($fileInfos as $fileInfo): //Infos sur l'image?>
			<li><?= $fileInfo; ?></li>
		<?php endforeach; ?>
	</ul>
</div>
<?php
require_once 'inc/db.php';
$db->query('UPDATE utilisateur SET photo_profil = ? WHERE id = ?',[$nom, $user_id]);

?>

<?php endif; ?>


<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.11.3/jquery.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js"></script>
<script src="https:////ajax.googleapis.com/ajax/libs/jqueryui/1.11.2/jquery-ui.min.js"></script>
<script src="js/upload.js"></script>

