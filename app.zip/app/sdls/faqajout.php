<?php
require_once 'inc/bootstrap.php';
require_once 'inc/db.php';
if(!empty($_POST)){

// Formulaire

	$question = htmlspecialchars($_POST['FAQ_question']);
	$reponse = htmlspecialchars($_POST['FAQ_reponse']);
	$db->query('INSERT INTO faq (FAQ_question,FAQ_reponse) VALUES (?,?)',[$question,$reponse]);

}
header("Location: faqadmin.php");
exit();
?>