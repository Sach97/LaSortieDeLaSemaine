-- phpMyAdmin SQL Dump
-- version 4.1.14
-- http://www.phpmyadmin.net
--
-- Client :  127.0.0.1
-- Généré le :  Dim 05 Juin 2016 à 14:51
-- Version du serveur :  5.6.17
-- Version de PHP :  5.5.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Base de données :  `sdls_soutenance`
--

-- --------------------------------------------------------

--
-- Structure de la table `evenement`
--

CREATE TABLE IF NOT EXISTS `evenement` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(75) NOT NULL,
  `date_debut` date NOT NULL,
  `heure_debut` time NOT NULL,
  `date_fin` date NOT NULL,
  `heure_fin` time NOT NULL,
  `adresse` varchar(275) NOT NULL,
  `num_adresse` int(11) NOT NULL,
  `code_postal` int(11) NOT NULL,
  `description` longtext NOT NULL,
  `photo` text NOT NULL,
  `nombre_place` int(11) NOT NULL,
  `createur` varchar(75) NOT NULL,
  `theme_interet` varchar(75) NOT NULL,
  `prive` int(11) NOT NULL DEFAULT '0',
  `signaler` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=138 ;

--
-- Contenu de la table `evenement`
--

INSERT INTO `evenement` (`id`, `nom`, `date_debut`, `heure_debut`, `date_fin`, `heure_fin`, `adresse`, `num_adresse`, `code_postal`, `description`, `photo`, `nombre_place`, `createur`, `theme_interet`, `prive`, `signaler`) VALUES
(119, 'Portes ouvertes au musée du Louvre', '2016-01-30', '14:00:00', '2016-01-30', '17:00:00', 'Musée du Louvre, Paris 1er ', 0, 75001, 'Venez découvrir les pièces rares et variées du musée du Louvre gratuitement, avec votre famille ou vos amis!', '119.jpg', 500, '42', 'Culture', 0, 1),
(117, 'Rocky 7 : Creed', '2016-01-27', '20:00:00', '2016-01-27', '22:00:00', 'UGC Strasbourg Etoile', 0, 67000, 'Séance dédiée aux fans incorruptibles de Rocky. ', '117.jpg', 150, '44', 'Cinéma', 0, 0),
(120, 'OM-PSG', '2016-02-06', '21:00:00', '2016-02-06', '23:00:00', '3 Boulevard Michelet,  Marseille', 0, 13008, 'Le classico, le match de la saison en ligue 1! Que vous soyez supporters marseillais ou parisiens, venez y assister en nombre!', '120.jpg', 400, '42', 'Sport', 0, 0),
(121, 'Après-midi bronzage au Jardin du Luxembourg', '2016-08-10', '12:00:00', '2016-08-10', '18:00:00', 'rue de Vaugirard, Paris 6eme', 0, 75006, 'Une inactivité totale pour une après-midi pour tous ceux qui aiment glander et bronzer!', '121.jpg', 250, '44', 'Détente', 0, 1),
(122, 'Nek le Fennek', '2016-03-18', '21:00:00', '2016-03-18', '23:00:00', 'Zénith de Paris, 211 Avenue Jean Jaurès, Paris 19eme', 0, 75019, 'Ca va être le FEU, FEU, FEU, FEU!', '122.jpg', 150, '42', 'Musique', 0, 1),
(123, 'SOIREE SWAG', '2016-04-01', '23:00:00', '2016-04-02', '04:00:00', 'Mood Club, 18 rue du Commerce, Vendenheim', 0, 67550, 'Grosse soirée au Mood Club ce vendredi premier Avril! Venez nombreux et surtout... bien sapés! ', '123.jpg', 500, '44', 'Fête du Samedi Soir', 0, 0),
(124, 'Don Juan', '2016-02-06', '21:00:00', '2016-02-06', '23:00:00', '10 rue de Fontaine, Paris 9eme', 0, 75009, 'Venez nombreux pour la première de Don Juan au théâtre Fontaine! #ViveMolière', '124.jpg', 100, '42', 'Théâtre', 0, 0),
(125, 'Foire de Paris', '2016-04-29', '00:00:00', '2016-05-08', '00:00:00', 'Porte de Versailles, Paris 15eme', 0, 75015, 'L''événement shopping incontournable du printemps qui vous propose des produits pour la maison, la gastronomie, la beauté…', '125.jpg', 240, '44', 'Shopping', 0, 0),
(137, 'Top chef', '2016-03-03', '03:03:00', '2016-03-03', '03:03:00', '28 rue notre dame des champs ', 0, 75014, 'Concours', '137.jpg', 6, '42', 'Gastronomie', 0, 0);

-- --------------------------------------------------------

--
-- Structure de la table `faq`
--

CREATE TABLE IF NOT EXISTS `faq` (
  `idFAQ` int(11) NOT NULL AUTO_INCREMENT,
  `FAQ_question` longtext,
  `FAQ_reponse` longtext,
  PRIMARY KEY (`idFAQ`)
) ENGINE=InnoDB  DEFAULT CHARSET=utf8 AUTO_INCREMENT=26 ;

--
-- Contenu de la table `faq`
--

INSERT INTO `faq` (`idFAQ`, `FAQ_question`, `FAQ_reponse`) VALUES
(1, 'Quel est l’intérêt de s’inscrire via les réseaux sociaux ?', 'Cette option vous offre entre autre la possibilité de savoir si certains de vos amis sur ces réseaux sociaux sont, eux aussi, inscrits sur notre site. Ils seront alors ajoutés à votre liste d''amis. Vous pourrez ainsi partager avec eux vos goûts, vos envies, et planifier vos sorties !'),
(2, 'Pourquoi est-on obligés de souscrire aux conditions générales d''utilisation ?', 'Elle est essentielle car en souscrivant aux CGU, vous nous permettez de collecter certaines de vos informations afin de vous proposer le meilleur service possible. A l’inverse, nous vous garantissons la protection de ces informations, ainsi qu’une sécurité optimale pour tout paiement par l’intermédiaire de notre site. Toutes les clauses sont répertoriées dans les-dites conditions générales d''utilisation.'),
(3, 'Pourquoi souscrire à la newsletter ?', 'C’est une option qui vous permettra d’être notifié de tout évènement étant susceptible de vous intéresser. Un plus pour vous!'),
(4, 'Je n’arrive pas à bénéficier des fonctionnalités du site !', 'C’est que vous n’êtes pas connecté ! Si vous n’avez pas de compte, inscrivez-vous !'),
(5, 'Quel est l’intérêt d’un forum sur une plateforme évènementielle ?', 'Il vous offre une multitude de possibilités, comme par exemple partager vos impressions, conseiller (ou déconseiller) un évènement, trouver des réponses aux questions qui n’en ont pas, et bien plus encore!'),
(6, 'Je ne reçois pas d’offres sur les évènements à proximité !', 'Si vous avez souscrit à la newsletter, c’est que vous n’avez pas indiqué le lieu de votre domicile. Précisez votre adresse dans votre profil.'),
(7, 'Comment faire pour poster des photos d’un évènement qui n’est pas proposé?', 'Vous ne pouvez pas interagir directement avec la galerie. Vous devez d’abord créer votre évènement. Ensuite, vos photos pourront être ajoutées à la description.'),
(8, 'Je n’arrive pas à trouver l’évènement qui me correspond!', 'Si la recherche par mots-clés ne vous comble pas, essayez la recherche avancée! Si cela ne vous aide pas, c’est que momentanément, le type d’évènement que vous recherchez n’est pas répertorié par notre site. Nous vous incitons à réessayer ultérieurement.'),
(9, 'Pourquoi noter un évènement?', 'Si vous notez sérieusement, cela offre à toute la communauté #SDLS la possibilité de choisir un évènement en fonction de sa note. C’est un critère essentiel si l’on veut être sûr de passer un bon moment!'),
(10, 'Que faire si un évènement que j’ai payé est annulé?', 'Vous serez renvoyé vers l’organisateur. Consultez vos mails!'),
(11, 'Peut-on participer à la préparation ou au déroulement d’un évènement?', 'C’est possible ! Si vous voulez vous investir, il vous suffit de vous inscrire à un évènement qui vous intéresse, et vous aurez la possibilité de proposer vos services!'),
(12, 'Je n’ai pas la solution à mon problème…', 'Contactez-nous ou postez un message sur le Forum, la communauté se fera un plaisir de vous répondre!'),
(23, 'asasas', 'asasasa'),
(24, 'Pourquoi la photo ne s''affiche pas correctement', 'A cause du format'),
(25, 'asas', 'asas');

-- --------------------------------------------------------

--
-- Structure de la table `forum_reponses`
--

CREATE TABLE IF NOT EXISTS `forum_reponses` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `texte` text NOT NULL,
  `auteur` varchar(255) NOT NULL,
  `date` date NOT NULL,
  `heure` time NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `forum_sujets`
--

CREATE TABLE IF NOT EXISTS `forum_sujets` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `auteur` varchar(60) NOT NULL,
  `titre` text NOT NULL,
  `date_derniere_reponse` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

--
-- Contenu de la table `forum_sujets`
--

INSERT INTO `forum_sujets` (`id`, `auteur`, `titre`, `date_derniere_reponse`) VALUES
(1, 'sacha', 'test', '2016-01-13 23:00:00'),
(2, 'Adrian', 'Super', '2016-01-13 22:31:41'),
(3, 'asas', 'asas', '2016-01-13 22:32:17'),
(4, 'asas', 'asas', '2016-01-13 22:33:33'),
(5, 'asas', 'asas', '2016-01-14 16:56:25');

-- --------------------------------------------------------

--
-- Structure de la table `media`
--

CREATE TABLE IF NOT EXISTS `media` (
  `m_id` int(11) NOT NULL AUTO_INCREMENT,
  `m_type` varchar(255) NOT NULL,
  `m_url` varchar(255) NOT NULL,
  PRIMARY KEY (`m_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `sponsor`
--

CREATE TABLE IF NOT EXISTS `sponsor` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(75) DEFAULT NULL,
  `site` varchar(275) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `type-place`
--

CREATE TABLE IF NOT EXISTS `type-place` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `nom` varchar(75) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- --------------------------------------------------------

--
-- Structure de la table `utilisateur`
--

CREATE TABLE IF NOT EXISTS `utilisateur` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `pseudo` varchar(255) CHARACTER SET utf8 NOT NULL,
  `nom` varchar(255) CHARACTER SET utf8 NOT NULL,
  `prenom` varchar(255) CHARACTER SET utf8 NOT NULL,
  `email` varchar(255) CHARACTER SET utf8 NOT NULL,
  `mdp` varchar(255) CHARACTER SET utf8 NOT NULL,
  `photo_profil` varchar(255) CHARACTER SET utf8 NOT NULL,
  `sexe` varchar(15) CHARACTER SET utf8 NOT NULL,
  `date_naissance` date NOT NULL,
  `adresse` varchar(255) NOT NULL,
  `num_adresse` int(11) NOT NULL,
  `code_postal` int(11) NOT NULL,
  `dj` tinyint(1) NOT NULL,
  `barman` tinyint(1) NOT NULL DEFAULT '0',
  `animateur` tinyint(1) NOT NULL,
  `serveur` tinyint(1) NOT NULL,
  `danseur` tinyint(1) NOT NULL,
  `securite` tinyint(1) NOT NULL,
  `admin` tinyint(1) DEFAULT NULL,
  `ban` tinyint(1) DEFAULT NULL,
  `confirmation_token` varchar(60) CHARACTER SET utf8 DEFAULT NULL,
  `confirmed_at` datetime DEFAULT NULL,
  `reset_token` varchar(60) CHARACTER SET utf8 DEFAULT NULL,
  `reset_at` datetime DEFAULT NULL,
  `remember_token` varchar(60) CHARACTER SET utf8 DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=55 ;

--
-- Contenu de la table `utilisateur`
--

INSERT INTO `utilisateur` (`id`, `pseudo`, `nom`, `prenom`, `email`, `mdp`, `photo_profil`, `sexe`, `date_naissance`, `adresse`, `num_adresse`, `code_postal`, `dj`, `barman`, `animateur`, `serveur`, `danseur`, `securite`, `admin`, `ban`, `confirmation_token`, `confirmed_at`, `reset_token`, `reset_at`, `remember_token`) VALUES
(42, 'Sach97', 'Arbonel', 'Sacha', 'sach972_madinina@hotmail.fr', '$2y$10$QG.b7u7UM8V9Ec6BxXUJPuM/9dvx0BiDpx94a1Gfh.LVL178ak/qG', '42.jpg\r\n', 'Homme', '1995-01-31', 'rue Cambronne', 60, 75015, 0, 0, 1, 0, 0, 0, 1, NULL, NULL, '0000-00-00 00:00:00', '9UNNagJhnZsW36SXySkJUaDkIkt0H4gaFTN6GwQivMbaYcTWtK7Mzy8Vp9fW', '2016-06-05 13:32:08', 'qGOvKbVb3AbI7tCWtcEqKcCJbr85uPgSgeFOJtBltgtV5eN9yEaUh2GkhCsA'),
(44, 'Jojo', 'Le Bars', 'Johan', 'jojo@gmail.com', '$2y$10$RucBJPJI2GzCh13UBgzTOuMrmg7IrchFLdZRnstUt4gqtBRbmgENC', '44.jpg', 'Homme', '0000-00-00', '', 0, 0, 0, 0, 0, 0, 0, 0, NULL, NULL, NULL, '2016-01-12 11:27:02', NULL, NULL, NULL),
(53, 'utilisateur', '', '', 'utilisateur@gmail.com', '$2y$10$zEFoo3wfSY64cQeH6XuH3eO4AdxqGkOjkKvtxi46/64oWJYypLREC', '53.png', '', '0000-00-00', '', 0, 0, 0, 0, 0, 0, 0, 0, 1, NULL, NULL, '2016-01-19 14:47:48', NULL, NULL, NULL),
(54, 'Test', '', '', 'test@hotmail.fr', '$2y$10$ezzm3t11YmoTkgb0SGzAI.5U1NgRmd2bG1Vl3a8/PD.xaGwnmPiYi', '', '', '0000-00-00', '', 0, 0, 0, 0, 0, 0, 0, 0, 1, NULL, NULL, '2016-06-05 14:04:23', NULL, NULL, NULL);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
